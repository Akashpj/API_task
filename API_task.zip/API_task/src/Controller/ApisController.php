<?php
namespace App\Controller;

use Cake\Core\Configure;
use Cake\Network\Exception\ForbiddenException;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;
use Cake\Network\Session;
use Cake\ORM\TableRegistry;

use App\Controller\AppController;

/**
 * Apis Controller
 *
 *
 * @method \App\Model\Entity\Api[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ApisController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $apis = $this->paginate($this->Apis);

        $this->set(compact('apis'));
    }

    /**
     * View method
     *
     * @param string|null $id Api id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view()
    {
        $this->loadModel('Books');
        $getBooks = array();

        $getBooks = $this->Books->getLoneBooks();

        echo json_encode($getBooks);exit;
        
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add($book_id,$cholder_id)
    {   
        $this->loadModel('Rental');
        $this->loadModel('Books');
        $this->loadModel('CardHolders');
        $result=array();
        if(empty($book_id)&&empty($cardholder_id))
        {
             $result['success'] = __('failure');
             $result['msg'] = __('Renatl Record failed to save');
        }
        else{
              $bid=$this->Books->find()->select(['Books.title'])->where(['Books.id'=>$book_id])->enableHydration(false)->first();
              $ch_id=$this->CardHolders->find()->select(['CardHolders.first_name'])->where(['CardHolders.id'=>$cholder_id])->enableHydration(false)->first();
              if(!empty($bid)&&!empty($ch_id))
              {
                  $rental = $this->Rental->newEntity();
                  $rental->book_id        = $book_id;
                  $rental->card_holder_id = $cholder_id;
                  $saved=$this->Rental->save($rental);
                 if($saved){
                    $result['success'] = __('success');
                    $result['msg'] = __('Retal Record saved successfully');

                   }
            }
            else{
                $result['success'] = __('failure');
                $result['msg'] = __('please make sure Book/Cardholder is available');
            }
        }
            echo json_encode($result);exit;
    }

   
}
