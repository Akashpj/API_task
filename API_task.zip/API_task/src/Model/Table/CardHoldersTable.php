<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * CardHolder Model
 *
 * @property \App\Model\Table\RentalTable&\Cake\ORM\Association\HasMany $Rental
 *
 * @method \App\Model\Entity\CardHolder get($primaryKey, $options = [])
 * @method \App\Model\Entity\CardHolder newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\CardHolder[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\CardHolder|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\CardHolder saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\CardHolder patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\CardHolder[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\CardHolder findOrCreate($search, callable $callback = null, $options = [])
 */
class CardHoldersTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('card_holders');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->hasMany('Rental', [
            'foreignKey' => 'card_holder_id',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmptyString('id', null, 'create');

        $validator
            ->scalar('first_name')
            ->maxLength('first_name', 255)
            ->requirePresence('first_name', 'create')
            ->notEmptyString('first_name');

        $validator
            ->scalar('last_name')
            ->maxLength('last_name', 255)
            ->requirePresence('last_name', 'create')
            ->notEmptyString('last_name');

        $validator
            ->scalar('cardNumber')
            ->maxLength('cardNumber', 255)
            ->requirePresence('cardNumber', 'create')
            ->notEmptyString('cardNumber');

        $validator
            ->dateTime('create_at')
            ->notEmptyDateTime('create_at');

        $validator
            ->dateTime('modify')
            ->notEmptyDateTime('modify');

        return $validator;
    }
}
